

https://github.com/CS-LTU/github-intro-imas19446698


Read Me File
My choice of tech stack is HTML and CSS. Web developers need to know HTML and CSS because they lay the groundwork for building organised, eye-catching, and responsive websites. They are extensively used, have strong support, and are always changing to keep up with the ever-changing needs of the web development industry.

The wide range of tools and services offered by cloud platforms makes application deployment and scaling easier. Software development and operations can become more flexible, efficient, and economical by utilising code, software deployment pipelines, scalable resources, and managed services.

Project Overview
The website aims to create an online place where students can find jobs and employers can advertise their jobs to students. The scope includes the employers that are looking to employ students and the students that are looking for jobs.


Project Plan
![Alt text](image-1.png)


Project Kickoff
Requirement Analysis
Design Phase
UI Development
Full App Development
Testing
Client Feedback
Launch
Define Scope
Identify Risks 


User Guide
1. Getting started 
Paste our website's URL into your open web browser.
Make sure your browser is up to date for the best experience.

2. Navigation
The website has an easy-to-use navigation system that makes exploring it simple.
To navigate between sections, use the menu bar at the top of the Intro page.

4. Management of Accounts 

Register 
You will be required to register in order to post job openings or apply for work. Select the "Sign Up" option, provide any required information then click the signup button.

Log in
To access your personal account, enter your login details.


Installation steps
Step One: First, download the file for the website.
Open the website file in a text editor such as Sublime Text or Visual Studio after downloading it.

Step2: Open the website file in step two.
Find the file for the website on your computer.
On the file, do a right-click.
From the context menu, select "Open With".
Choose the online browser that you choose, such as Google Chrome, Mozilla Firefox, or Safari.

Step 3: Check the Information
Your web browser should now display the content of the website file.
Check to make sure all links and interactive components work properly and that content displays as intended.





Legal And Ethical Considerations



Ethical Considerations:
1. Privacy: Gathering Individual Data: Be open and honest about the types of personal data you gather, their purposes, and your plans for using them. Prior to collecting any sensitive data, get user approval.

2. Accessibility: Make sure people with disabilities can access your website. This entails employing readable fonts, guaranteeing keyboard navigation, and offering alternatives for visual information.

3. Transparency: Be open and honest about any possible conflicts of interest, the nature of your content, and the goal of your website. Make sponsored material and affiliate ties very clear.
4. Content Accuracy: Verify that the data on your website is current and correct. Users may suffer and your reputation may suffer if you provide false or misleading information.

Legal Considerations

1. Intellectual property and copyright:

Follow copyright regulations. Verify that any content on the website is ours to use and display. Give credit where credit is due for content created by others.


2. Adherence to GDPR:

Make sure the website complies with the General Data Protection Regulation (GDPR) if it gathers data from users in Europe. Getting express consent is one way to do this before gathering personal data



3. Trademark Concerns:

To avoid legal problems, do not use trademarks without the required authority.

Review and update your website's rules and procedures on a regular basis to guarantee that they continue to adhere to applicable laws and ethical standards. 

4. Security and Data Breach Notification: To safeguard user data, put security measures in place. If there is a data breach, notify the impacted parties in accordance with the law.

Risk Assesment
A website's functioning, users, and data are all impacted by potential threats and vulnerabilities, which are identified as part of a risk assessment. Putting policies in place to lessen these risks is the aim.

1. Asset:

Website Resources:

domain name, user data, content, database, server architecture, and intellectual property.

2. Identification of Threats:

external dangers

malware, phishing, DDoS assaults, hacking, and illegal access.

Internal Dangers:

data breaches, insider risks, and unintentional data loss.

3. Vulnerability Assessment: Website Code: Outdated software and vulnerabilities in the website code.

Infrastructure of Servers:

Unpatched servers and inadequate security setups.

User Verification:

Poor password security and incorrect user authentication procedures.

4. Compliance: Make sure that all legal requirements—such as those pertaining to data protection and industry standards are met.

5. Review and Update: To keep up with changing threats, review and update the risk assessment and mitigation plans on a regular basis.


[gant.png]: gant.png